-- in src/main/resources/data.sql (runs on startup)
INSERT INTO app_user(id, username, password, role)
VALUES (1, 'alice', '{bcrypt}$2a$10$Wv5x5UhO2lfAghaGkKD3Je6Coc9eUsgckhdwdSPRlbx01vro7VIpe', 'ROLE_USER');
