package com.soundscore;

public @interface Test {

}
