package com.soundscore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.soundscore.entity.AppUser;
import com.soundscore.service.auth.UserService;

@EntityScan 
@ComponentScan
@RestController
@RequestMapping("/api/app_user")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Endpoint to create or register a user
    @PostMapping("/register")
    public AppUser registerUser(@RequestBody AppUser user) {
        return userService.save(user);
    }

    // Endpoint to get a user by id
    @GetMapping("/{id}")
    public AppUser getUserById(@PathVariable Long id) {
        return userService.findById(id);
    }

    // Endpoint to get a user by username (for login or authentication)
    @GetMapping("/username/{username}")
    public AppUser getUserByUsername(@PathVariable String username) {
        return userService.findByUsername(username);
    }
}
