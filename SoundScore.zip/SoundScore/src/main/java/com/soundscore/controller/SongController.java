package com.soundscore.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.soundscore.entity.AppSong;
import com.soundscore.service.SongService;

@EntityScan 
@ComponentScan
@RestController
@RequestMapping("/api/app_song")
public class SongController {

    private final SongService songService;

    @Autowired
    public SongController(SongService songService) {
        this.songService = songService;
    }

    // Endpoint to create or update a song
    @PostMapping
    public AppSong createOrUpdateSong(@RequestBody AppSong song) {
        return songService.save(song);
    }

    // Endpoint to get all songs
    @GetMapping
    public List<AppSong> getAllSongs() {
        return songService.findAll();
    }

    // Endpoint to get a song by its ID
    @GetMapping("/{id}")
    public Optional<AppSong>getSongById(@PathVariable Long id) {
        return songService.findById(id);
    }

    // Endpoint to delete a song by its ID
    @DeleteMapping("/{id}")
    public void deleteSong(@PathVariable Long id) {
        songService.deleteById(id);
    }
}
