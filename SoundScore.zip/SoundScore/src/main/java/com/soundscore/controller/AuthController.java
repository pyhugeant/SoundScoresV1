package com.soundscore.controller;

import com.soundscore.security.jwt.JwtService;

import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

import com.soundscore.config.RequiredArgsConstructor;
import com.soundscore.dto.auth.LoginRequest;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthenticationManager authManager = null;
    private final JwtService jwt = null;
    private final UserDetailsService userDetailsService;

    public AuthController() {
        this.userDetailsService = null;
    }

    @PostMapping("/login")
    public JwtResponse login(@RequestBody LoginRequest request) {

        Authentication authentication =
            new UsernamePasswordAuthenticationToken(request.getUsername(), request.password());

        authManager.authenticate(authentication);  // throws if bad creds

        // Load full UserDetails to include roles in further enhancements
        UserDetails user = userDetailsService.loadUserByUsername(request.getUsername());

        String token = jwt.generateToken(user.getUsername());
        return new JwtResponse(token);
    }
}
