package com.soundscore.service.auth;


import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.User.UserBuilder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.soundscore.config.RequiredArgsConstructor;
import com.soundscore.entity.AppUser;
import com.soundscore.repository.UserRepository;

@Service
@RequiredArgsConstructor
public class JpaUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository = null;

    @Override
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {

        return userRepository.findByUsername(username)     // Optional<AppUser>
            .map(this::toUserDetails)
            .orElseThrow(() ->
                 new UsernameNotFoundException("User %s not found".formatted(username)));
    }

    private UserDetails toUserDetails(AppUser u) {
        UserBuilder builder = User.withUsername(u.getUsername())
                                  .password(u.getPassword())   // already BCrypt‑encoded
                                  .roles(u.getRole());         // single role string
        return builder.build();
    }
}

