package com.soundscore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.soundscore.entity.AppSong;
import com.soundscore.repository.SongRepository;

@EntityScan 
@ComponentScan
@Service
public class SongService {

    private final SongRepository songRepository;

    @Autowired
    public SongService(SongRepository songRepository) {
        this.songRepository = songRepository;
    }

    // Method to save a new song or update an existing one
    public AppSong save(AppSong song) {
        return songRepository.save(song);
    }

    // Method to find a song by its ID
    public Optional<AppSong> findById(Long id) {
        return songRepository.findById(id);
    }

    // Method to find all songs
    public List<AppSong> findAll() {
        return songRepository.findAll();
    }

    // Method to delete a song by its ID
    public void deleteById(Long id) {
        songRepository.deleteById(id);
    }
}
