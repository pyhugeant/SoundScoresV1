package com.soundscore.service.auth;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

import com.soundscore.dto.ApiResponse;
import com.soundscore.dto.auth.LoginRequest;
import com.soundscore.dto.auth.RegisterRequest;
import com.soundscore.entity.AppUser;

@EntityScan 
@ComponentScan
public interface UserService {
    ApiResponse register(RegisterRequest request);
    String authenticate(LoginRequest request);
    AppUser save(AppUser user);
    AppUser findById(Long id);
    AppUser findByUsername(String username);
}

