package com.soundscore.service.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.soundscore.dto.ApiResponse;
import com.soundscore.dto.auth.LoginRequest;
import com.soundscore.dto.auth.RegisterRequest;
import com.soundscore.entity.AppUser;
import com.soundscore.repository.UserRepository;
import com.soundscore.util.JwtTokenProvider;

@EntityScan 
@ComponentScan
@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepo;
    private final AuthenticationManager authManager;
    private final JwtTokenProvider tokenProvider;
    private final AuthenticationManager authenticationManager;

        private UserRepository userRepository = null;

    @Autowired
    public UserServiceImpl(UserRepository userRepo, AuthenticationManager authManager, JwtTokenProvider tokenProvider, UserRepository userRepository, AuthenticationManager authenticationManager) {
        this.userRepo = userRepo;
        this.authManager = authManager;
        this.tokenProvider = tokenProvider;
        this.userRepository = userRepository;
        this.authenticationManager = authenticationManager;
    }

    public AppUser getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }
    
    @Override
    public ApiResponse register(RegisterRequest request) {
        // Registration logic (already implemented)
        return null;
    }

    @Override
    public String authenticate(LoginRequest request) {
        // Authenticate the user
        Authentication authentication = authManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));
        
        SecurityContextHolder.getContext().setAuthentication(authentication);
        
        return tokenProvider.createToken(authentication);
    }

    public UserRepository getUserRepo() {
        return userRepo;
    }

    public AuthenticationManager getAuthenticationManager() {
        return authenticationManager;
    }

    @Override
    public AppUser save(AppUser user) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public AppUser findById(Long id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public AppUser findByUsername(String username) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}

