package com.soundscore.util;

import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtTokenProvider {

    private final SecretKey key = Keys.hmacShaKeyFor(
        "aVeryLong32+byteSuperSecretKeyChangeMeNow123!".getBytes());
    private final long expMs = 3600000;   // 1 h

    public String buildToken(String username) {
        Date now = new Date();
        return Jwts.builder()
                   .subject(username)
                   .issuedAt(now)
                   .expiration(new Date(now.getTime() + expMs))
                   .signWith(key, Jwts.SIG.HS256)
                   .compact();
    }

    public String createToken(Authentication authentication) {
        throw new UnsupportedOperationException("Unimplemented method 'createToken'");
    }
}
