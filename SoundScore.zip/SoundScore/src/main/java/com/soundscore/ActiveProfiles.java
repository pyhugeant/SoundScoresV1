package com.soundscore;

public @interface ActiveProfiles {

    String value();

}
