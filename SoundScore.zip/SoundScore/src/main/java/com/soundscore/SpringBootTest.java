package com.soundscore;

public @interface SpringBootTest {

}
