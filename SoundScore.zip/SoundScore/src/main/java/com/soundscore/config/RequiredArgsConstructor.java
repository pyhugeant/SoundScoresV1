package com.soundscore.config;

public @interface RequiredArgsConstructor {

}
