package com.soundscore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories("com.soundscore.repository")
@EntityScan("com.soundscore.entity")
@ComponentScan("com.soundscore")
@ComponentScan("com.soundscore.service.auth")
public class SoundScoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(SoundScoreApplication.class, args);
    }
}
